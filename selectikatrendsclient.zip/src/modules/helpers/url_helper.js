export const AppUrl = `${window.location.protocol}//${window.location.hostname}${window.location.hostname === 'localhost' ? ':3000' : ''}`;

